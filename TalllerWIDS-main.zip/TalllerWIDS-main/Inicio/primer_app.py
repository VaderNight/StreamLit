
# En esta app exploraremos varios componentes que permiten visualizar datos e información en una aplicación

# "Calidad de vida a nivel mundial")

###################################
# markdown
##################################

# Lista de Indicadores

###################################
# Tabla de datos
##################################

###################################
# Gráfico de barras
##################################


###################################
# Histograma de frecuencias
##################################


###################################
# Gráfica de caja y bigotes
##################################


###################################
# Gráfica de dispersión
##################################

# Gráfica de dispersión
